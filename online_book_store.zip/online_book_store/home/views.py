from django.shortcuts import render,HttpResponse
from .models import contact_master
# Create your views here.

def home(request):
    return render(request,'home.html')

def contact(request):
    if request.method=="POST":
        name=request.POST['name']
        email=request.POST['email']
        subject=request.POST['subject']
        message=request.POST['message']
        ob=contact_master.objects.create(name=name,email=email,subject=subject,message=message)
        ob.save()
        return render(request,'contact.html',{'msg':'submit success'})
    return render(request,'contact.html')

def about(request):
    return render(request,'about.html')

def faq(request):
    return render(request,'faq.html')

def gallery(request):
    return render(request,'gallery.html')

def add(request):
    if request.method=="POST":
        a=int(request.POST['fno'])
        b=int(request.POST['sno'])
        result=a+b
        return render(request,'add.html',{'output':result})
    return render(request,'add.html')