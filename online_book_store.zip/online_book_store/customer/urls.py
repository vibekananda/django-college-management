from django.urls import path
from customer import views

urlpatterns = [
    path('cus_home/',views.cus_home,name='cus_home'),
]