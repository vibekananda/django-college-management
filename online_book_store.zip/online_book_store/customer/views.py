from django.shortcuts import render,get_object_or_404
from django.http import JsonResponse
from publisher.models import add_book,catagory

# Create your views here.
def cus_home(request):
    name=request.session.get('name')
    return render(request,'cus_home.html',{'name':name})

def bookcatagory(request):
    ob = catagory.objects.all()
    if request.method == "POST":
        cname = request.POST.get('cname')  
        try:
            catagory = get_object_or_404(catagory, c_name=cname)  
            books = add_book.objects.filter(c_name=catagory)  

            book_data = []
            for book in books:
                book_data.append({
                    'book_name': book.Book_name,
                    'author_name': book.Author,
                    'isbn': book.ISBN,
                    'price': book.Price,
                    'discount': book.Discount,
                    'image': book.Book_image.url,  # Get image URL
                    'review': book.Review
                })

            return JsonResponse({'data': {'books': book_data}})
        except catagory.DoesNotExist:  
            return JsonResponse({'data': {'books': []}}) 
    
    return render(request, 'book_category.html',{'bdata':ob})


def add_to_cart(request):
    if request.method == "POST":
        isbn = request.POST.get('isbn')
        if "cart" not in request.session:
            request.session['cart'] = []
        cart = request.session['cart']
        found = False
        for item in cart:
            if item['isbn'] == isbn:
                item['quantity'] += 1
                found = True
                break
        if not found:
            book = add_book.objects.get(ISBN=isbn)
            if book:
                book_data = {
                    "isbn": book.ISBN,
                    "Book_name": book.Book_name,
                    "Author": book.Author,
                    "Price": book.Price,
                    "Discount": book.Discount,
                    "Book_image": book.Book_image.url,
                    "quantity": 1
                }
                cart.append(book_data)
                request.session['cart'] = cart
                request.session.modified = True
                return JsonResponse({'message': 'Book added to cart', "cart_size": len(cart)})
    return JsonResponse({'message': 'Invalid Request'}, status=400)

def view_cart(request):
    cart=request.session.get('cart',[])
    return render(request,'cart.html',{'cart':cart})

def remove_from_cart(request):
    if request.method == "POST":
        isbn=request.POST.get('isbn')
        cart=request.session.get('cart',[])
        cart=[book for book in cart if book['ISBN']!=isbn]
        request.session['cart']=cart
        request.session.modified=True
        return JsonResponse({'message':'Book removed from cart',"cart_size":len(cart)})
    return JsonResponse({'message':'Invalid Request'},status=400)