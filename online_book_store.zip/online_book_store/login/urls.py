from django.urls import path
from login import views

urlpatterns = [
    path('pub_login/',views.pub_login,name='pub_login'),
    path('cus_login/',views.cus_login,name='cus_login'),
]