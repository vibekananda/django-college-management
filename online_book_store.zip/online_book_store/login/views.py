from django.shortcuts import render,redirect
from register.models import publisher_register,customer_register
# Create your views here.

def cus_login(request):
    if request.method=="POST":
        email=request.POST['cemail']
        password=request.POST['cpwd']
        try:
            ob=customer_register.objects.get(cemail=email,cpassword=password)
            request.session['name']=ob.cname
            request.session['pemail']=ob.cemail
            
            return redirect('cus_home')
        except Exception as e:
            return render(request,'cus_login.html',{'msg':'invalid'+str(e)})
    return render(request,'cus_login.html')

def pub_login(request):
    if request.method=="POST":
        email=request.POST['pemail']
        password=request.POST['ppwd']
        try:
            ob=publisher_register.objects.get(pemail=email,ppassword=password)
            request.session['name']=ob.pname
            request.session['pemail']=ob.pemail
            
            if ob.status==0:
                return render(request,'pub_login.html',{'msg':'waiting for the admin conformation'})
            elif ob.status==1:
                return redirect('pub_home')
        except Exception as e:
            return render(request,'pub_login.html',{'msg':'invalid'+str(e)})
    return render(request,'pub_login.html')