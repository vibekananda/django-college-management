from django.shortcuts import render,redirect
from .models import catagory,add_book
from register.models import publisher_register
# Create your views here.
def pub_home(request):
    name=request.session.get('name')
    return render(request,'pub_home.html',{"name":name})

def addbook(request):
    ob=catagory.objects.all()
    if request.method=="POST":
        cname=request.POST['cname']
        catagory_name=catagory.objects.get(c_name=cname)
        bname=request.POST['bname']
        aname=request.POST['aname']
        isbnno=request.POST['isbn']
        bprice=request.POST['bprice']
        dic=request.POST['dis']
        image=request.FILES['bimage']
        obj=add_book.objects.create(c_name=catagory_name,book_name=bname,author_name=aname,ISBN_no=isbnno,book_price=bprice,discount=dic,book_image=image)
        obj.save()
        return render(request,"addbook.html",{'msg':"add book sucessfully"})
    return render(request,'addbook.html',{'cdata':ob})

def viewbook(request):
    ob=add_book.objects.all()
    if request.method=="POST":
        btn=request.POST["btn"]
        isbnno=request.POST["isbnno"]
        if btn=="delete":
            try:
                ob=add_book.objects.get(ISBN_no=isbnno).delete()
                obj=add_book.objects.all()
                return redirect("viewbook")
            except Exception:
                return redirect("viewbook")
        if btn=="edit":
            try:
                obj=add_book.objects.get(ISBN_no=isbnno)
                return render(request,"edit.html",{"data":obj})
            except Exception:
                return redirect("viewbook")
    return render(request,"viewbook.html",{"bookdata":ob})


def update(request):
    if request.method=="POST":
        isbnno=request.POST["isbnno"]
        bname=request.POST["bname"]
        bprice=request.POST["bprice"]
        aname=request.POST["aname"]
        dis=request.POST["dis"]
        image_file=request.FILES["image"]
        # obj=add_book.objects.filter(ISBN_no=isbnno).update(book_name=bname,book_price=bprice,author_name=aname,discount=dis)
        ob,created=add_book.objects.get_or_create(ISBN_no=isbnno)
        ob.book_name=bname
        ob.book_price=bprice
        ob.author_name=aname
        ob.discount=dis

        if image_file:
            ob.book_image=image_file
        ob.save()
        return redirect("viewbook")
    return render(request,"edit.html")

def profile(request):
    pname=request.session.get('name')
    pemail=request.session.get('pemail')
    ob=publisher_register.objects.get(pemail=pemail)
    return render(request,"pprofile.html",{"msg":ob})