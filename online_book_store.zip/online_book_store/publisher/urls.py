from django.urls import path
from publisher import views

urlpatterns = [
    path('pub_home/',views.pub_home,name='pub_home'),
    path('addbook/',views.addbook,name='addbook'),
    path('viewbook/',views.viewbook,name='viewbook'),
    path('update/',views.update,name='update'),
    path('profile/',views.profile,name='profile'),
]