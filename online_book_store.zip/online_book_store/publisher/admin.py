from django.contrib import admin
from .models import catagory,add_book
# Register your models here.
admin.site.register(catagory)
admin.site.register(add_book)