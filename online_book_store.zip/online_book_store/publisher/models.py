from django.db import models

# Create your models here.
class catagory(models.Model):
    c_id=models.AutoField(primary_key=True)
    c_name=models.CharField(max_length=50)
    def __str__(self):
        return self.c_name
    
class add_book(models.Model):
    c_name=models.ForeignKey(catagory,on_delete=models.CASCADE)
    book_name=models.CharField(max_length=40)
    author_name=models.CharField(max_length=30)
    ISBN_no=models.CharField(primary_key=True,max_length=100)
    book_price=models.FloatField()
    discount=models.IntegerField()
    book_image=models.ImageField(upload_to='book_image/')
    review=models.CharField(max_length=30,default="None")
    def __str__(self):
        return self.book_name
    