from django.shortcuts import render
from .models import publisher_register
from .models import customer_register
# Create your views here.
def pub_register(request):
    if request.method=="POST":
        name=request.POST['pname']
        email=request.POST['pemail']
        mobile=request.POST['pmobileno']
        pwd=request.POST['ppwd']
        doc=request.FILES['pdoc']
        address=request.POST['paddress']
        ob=publisher_register.objects.create(pname=name,pemail=email,pmobileno=mobile,ppassword=pwd,document=doc,paddress=address)
        ob.save()
        return render(request,'publisher_register.html',{'msg':'register success'})
    return render(request,'publisher_register.html')

def cus_register(request):
    if request.method=="POST":
        name=request.POST['cname']
        contact=request.POST['ccontact']
        email=request.POST['cemail']
        pwd=request.POST['cpwd']
        DOB=request.POST['cdob']
        address=request.POST['caddress']
        image=request.FILES['cimage']
        ob=customer_register.objects.create(cname=name,ccontact=contact,cemail=email,cpassword=pwd,cDOB=DOB,caddress=address,cimage=image)
        ob.save()
        return render(request,'customer_register.html',{'msg':'register success'})
    return render(request,'customer_register.html')