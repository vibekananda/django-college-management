from django.urls import path
from register import views

urlpatterns = [
    path('pubregister/',views.pub_register,name='pubregister'),
    path('cusregister/',views.cus_register,name='cusregister'),
]