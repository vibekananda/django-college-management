from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(publisher_register)
admin.site.register(customer_register)