from django.db import models
from django.utils import timezone
# Create your models here.
class publisher_register(models.Model):
    pname=models.CharField(max_length=50)
    pemail=models.EmailField(primary_key=True,max_length=60)
    pmobileno=models.CharField(max_length=50)
    ppassword=models.CharField(max_length=50)
    date=models.DateField(default=timezone.now)
    document=models.FileField(upload_to='document/')
    paddress=models.CharField(max_length=100)
    status=models.IntegerField(default=0)
    def __str__(self):
        return self.pname

class customer_register(models.Model):
    cname=models.CharField(max_length=50)
    ccontact=models.CharField(max_length=50)
    cemail=models.EmailField(primary_key=True,max_length=50)
    cpassword=models.CharField(max_length=50)
    cDOB=models.DateField()
    caddress=models.CharField(max_length=100)
    cimage=models.FileField(upload_to='document/')
    def __str__(self):
        return self.cname